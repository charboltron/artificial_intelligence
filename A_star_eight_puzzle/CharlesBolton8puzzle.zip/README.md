Run the puzzle solver like this:

python3 eight_puzzle_final.py _ 5 2 1 8 3 4 7 6

where the underscore represents the blank space. 
A* prints the puzzle solution as a visual puzzle.

The program checks for incorrect input but the input testing
only covers length, so make sure you only input permutations

of the form 1 2 3 4 5 6 7 8 _